#!/bin/sh

echo "hello world"

osascript -e 'display dialog "Your message here"'
